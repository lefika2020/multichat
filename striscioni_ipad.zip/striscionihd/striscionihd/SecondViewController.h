//
//  SecondViewController.h
//  striscioni
//
//  Created by GC  on 20/05/14.
//  Copyright (c) 2014 giulio caruso. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController
{
    IBOutlet UITextView *txtInfo;
}
@property (nonatomic,retain) UITextView *txtInfo;

@end
